import React, { useState } from "react";
import Modal from "../layout/modal";
import DatePicker from "react-datepicker";
import { useDoctorsStore } from "../../store/doctors.store";

const BookDoctor = ({ isModalOpen, setIsModalOpen, doctorDetails }) => {
  const [day, setday] = useState(new Date());
  const [selectedTime, setSelectedTime] = useState(null);
  const { bookAppointment } = useDoctorsStore();
  console.log(
    "day",
    day
  );
  const handleConfirm = () => {
    console.log("Selected Time", selectedTime);
    console.log("Appointment confirmed for", day);
  
    bookAppointment(
      doctorDetails.id,
      day.toISOString().split("T")[0],
      selectedTime
    );
    setIsModalOpen(false);
    setday(new Date());
    setSelectedTime(null);
  };
  const formatToAMPM = (date) => {
    let hours = date.getHours();
    const minutes = date.getMinutes();
    const period = hours >= 12 ? 'PM' : 'AM';

    hours = hours % 12;
    hours = hours ? hours : 12; 
    return `${hours}:${minutes < 10 ? '0' + minutes : minutes} ${period}`;
  };

 
  return (
    <div>
      <button
        onClick={() => setIsModalOpen(true)}
        data-modal-target="default-modal"
        data-modal-toggle="default-modal"
        className="inline-flex items-center px-3 py-2 text-sm font-medium text-center text-white bg-[#10AAC7] rounded-lg hover:bg-[#364153] focus:ring-4 focus:outline-none focus:ring-blue-300"
      >
        Book Appointment
      </button>
      <Modal
        isOpen={isModalOpen}
        disabled={!selectedTime || !day}
        onClose={() => setIsModalOpen(false)}
        title="Terms of Service"
        onConfirm={handleConfirm}
        // onDecline={handleDecline}
      >
        <h3 className="text-xl font-semibold text-gray-900 mb-4">
          {doctorDetails.name}
        </h3>
        <p className="mb-4 text-gray-700">{doctorDetails.specialty}</p>
        <p className="mb-4 text-gray-700">{doctorDetails.location}</p>
        <DatePicker showIcon       minDate={new Date(), 5} inline selected={day} onChange={(date) => 
          { setday(date) 
          console.log(date,"asasa")}} />

        <ul className="space-y-4 my-4 ">
          {doctorDetails?.availabilityTime[
            day.toLocaleDateString("en-US", { weekday: "long" }).toLowerCase()
          ]?.map((item, index) => {
            const timeId = `appointment-${item.id || index}`;
            console.log(
              "Booked Dates",
              doctorDetails.bookedDates?.[day.toISOString().split("T")[0]] || {}
            );
            return (
              <li key={index}>
                <input
                  onChange={() => setSelectedTime(item)}
                  type="radio"
                  id={timeId}
                  name="appointment"
                  value={item.id}
                  aria-checked={selectedTime?.id === item.id}
                  className="hidden peer"
                  checked={selectedTime?.id === item.id}
                  readOnly
                />
                <label
                  htmlFor={timeId}
                  className="inline-flex items-center justify-between w-full p-5 text-gray-900 bg-white border border-gray-200 rounded-lg cursor-pointer peer-focus-visible:ring-2 peer-focus-visible:ring-blue-500 peer-checked:bg-blue-200 hover:bg-gray-100"
                >
                  <div className="block">
                  {formatToAMPM(new Date(item?.startTime))}
                    -
                  {formatToAMPM(new Date(item?.endTime))}
                  </div>
                </label>
              </li>
            );
          })}
        </ul>
      </Modal>
    </div>
  );
};

export default BookDoctor;
